from __future__ import annotations

from pathlib import Path
import os
import re
import sys


BASE_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = BASE_DIR.parent

if str(PROJECT_ROOT) not in sys.path:
    # Keep project root for eva/* imports, but prefer modules inside ui/.
    sys.path.append(str(PROJECT_ROOT))


_PROP_RE = re.compile(r"^([^=]+)=(.*)$")


def _parse_kv_text(text: str) -> dict[str, str]:
    data: dict[str, str] = {}
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = _PROP_RE.match(line)
        if not match:
            continue
        key = match.group(1).strip()
        value = match.group(2).strip()
        if value.startswith(("'", '"')) and len(value) >= 2 and value[-1] == value[0]:
            quote = value[0]
            value = value[1:-1]
            if quote == '"':
                value = value.replace('\\"', '"')
            elif quote == "'":
                value = value.replace("\\'", "'")
        data[key] = value
    return data


def _parse_kv_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    return _parse_kv_text(path.read_text(encoding="utf-8"))


def _resolve_path(raw: str, fallback: str) -> Path:
    value = (raw or fallback).strip()
    path = Path(value)
    if not path.is_absolute():
        path = (PROJECT_ROOT / path).resolve()
    return path


APPLICATION_PROPERTIES_NAME = "application.properties"
DATASOURCES_PROPERTIES_NAME = "datasources.properties"
ACTIONS_PROPERTIES_NAME = "actions.properties"
HELPER_PROPERTIES_NAME = "helper.properties"

_app_properties_path_raw = os.getenv("ANBU_APPLICATION_PROPERTIES_FILE", "").strip()
_app_properties_path = Path(_app_properties_path_raw) if _app_properties_path_raw else (PROJECT_ROOT / APPLICATION_PROPERTIES_NAME)
if not _app_properties_path.is_absolute():
    _app_properties_path = (PROJECT_ROOT / _app_properties_path).resolve()
APP_PROPERTIES = _parse_kv_file(_app_properties_path)

SECRET_KEY = os.getenv(
    "DJANGO_SECRET_KEY",
    "unsafe-dev-secret-key-change-in-production",
)

DEBUG = os.getenv("DJANGO_DEBUG", "1").strip() in {"1", "true", "True", "yes", "YES"}
ALLOWED_HOSTS = os.getenv("DJANGO_ALLOWED_HOSTS", "*").split(",")

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "apps.targets",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

_ds_host = (
    os.getenv("DS_HOST", "").strip()
    or os.getenv("PGHOST", "").strip()
    or APP_PROPERTIES.get("DS_HOST", APP_PROPERTIES.get("PG_HOST", "")).strip()
)
_ds_port = (
    os.getenv("DS_PORT", "").strip()
    or os.getenv("PGPORT", "").strip()
    or APP_PROPERTIES.get("DS_PORT", APP_PROPERTIES.get("PG_PORT", "5432")).strip()
    or "5432"
)
_ds_dbname = (
    os.getenv("DS_DBNAME", "").strip()
    or os.getenv("PGDATABASE", "").strip()
    or APP_PROPERTIES.get("DS_DBNAME", APP_PROPERTIES.get("PG_DBNAME", "")).strip()
)
_ds_user = (
    os.getenv("DS_USER", "").strip()
    or os.getenv("PGUSER", "").strip()
    or APP_PROPERTIES.get("DS_USER", APP_PROPERTIES.get("PG_USER", "")).strip()
)
_ds_pass = (
    os.getenv("DS_PASS", "").strip()
    or os.getenv("PGPASSWORD", "").strip()
    or APP_PROPERTIES.get("DS_PASS", APP_PROPERTIES.get("PG_PASS", "")).strip()
)

if not (_ds_host and _ds_dbname and _ds_user):
    raise RuntimeError(
        "PostgreSQL config is required. Set DS_HOST, DS_DBNAME and DS_USER "
        "in application.properties (or property_file)."
    )

_postgres_db: dict[str, str | int] = {
    "ENGINE": "django.db.backends.postgresql",
    "HOST": _ds_host,
    "PORT": _ds_port,
    "NAME": _ds_dbname,
    "USER": _ds_user,
    "PASSWORD": _ds_pass,
    "CONN_MAX_AGE": 60,
}

DATABASES = {
    "default": dict(_postgres_db),
    "data_store": dict(_postgres_db),
}

DATABASE_ROUTERS = ["apps.targets.db_router.TargetsDbRouter"]

AUTH_PASSWORD_VALIDATORS = []

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "targets:list"
LOGOUT_REDIRECT_URL = "login"

ANBU_RULES_DIR = _resolve_path(APP_PROPERTIES.get("RULES_DIR", ""), "./rules")
ANBU_SAVED_QUERIES_DIR = _resolve_path(
    APP_PROPERTIES.get("SAVED_QUERIES_DIR", ""),
    "./saved_queries",
)
ANBU_APP_LOGO_FILE = _resolve_path(
    APP_PROPERTIES.get("APP_LOGO_FILE", ""),
    "./ui/static/assets/ico.png",
)
ANBU_AI_PROMPT_FILE = _resolve_path(
    APP_PROPERTIES.get("AI_PROMPT_FILE", ""),
    "./prompts/target_ai_prompt.txt",
)
# Datasource/action/application/helper properties are stored in default DB (property_file).
ANBU_DATASOURCE_DEFINITION_FILE = None
